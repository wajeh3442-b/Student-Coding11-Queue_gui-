import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class gui extends JFrame {

    private int front = -1, rear = -1, capacity;
    private String[] queue;

    private JTextField sizeField, valueField;
    private JPanel queuePanel;
    private JButton setSizeBtn, enqueueBtn, dequeueBtn, peekBtn, isEmptyBtn, isFullBtn, sizeBtn;

    public gui() {
        setTitle("Queue Visualization");
        setSize(500, 550);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel title = new JLabel("QUEUE (FIFO)");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBounds(160, 10, 300, 30);
        add(title);

        JLabel sizeLabel = new JLabel("Enter Queue Size:");
        sizeLabel.setBounds(40, 60, 140, 25);
        add(sizeLabel);

        sizeField = new JTextField();
        sizeField.setBounds(160, 60, 80, 25);
        add(sizeField);

        setSizeBtn = new JButton("Set Size");
        setSizeBtn.setBounds(260, 60, 100, 25);
        add(setSizeBtn);

        queuePanel = new JPanel();
        queuePanel.setBounds(40, 120, 400, 80);
        queuePanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        add(queuePanel);

        JLabel valueLabel = new JLabel("Value:");
        valueLabel.setBounds(40, 230, 100, 25);
        add(valueLabel);

        valueField = new JTextField();
        valueField.setBounds(90, 230, 100, 25);
        add(valueField);

        enqueueBtn = new JButton("enqueue()");
        enqueueBtn.setBounds(40, 280, 120, 30);
        add(enqueueBtn);

        dequeueBtn = new JButton("dequeue()");
        dequeueBtn.setBounds(180, 280, 120, 30);
        add(dequeueBtn);

        peekBtn = new JButton("peek()");
        peekBtn.setBounds(320, 280, 120, 30);
        add(peekBtn);

        isEmptyBtn = new JButton("isEmpty()");
        isEmptyBtn.setBounds(40, 330, 120, 30);
        add(isEmptyBtn);

        isFullBtn = new JButton("isFull()");
        isFullBtn.setBounds(180, 330, 120, 30);
        add(isFullBtn);

        sizeBtn = new JButton("size()");
        sizeBtn.setBounds(320, 330, 120, 30);
        add(sizeBtn);

        disableButtons();

        setSizeBtn.addActionListener(e -> setQueueSize());
        enqueueBtn.addActionListener(e -> enqueue());
        dequeueBtn.addActionListener(e -> dequeue());
        peekBtn.addActionListener(e -> peek());
        isEmptyBtn.addActionListener(e -> checkEmpty());
        isFullBtn.addActionListener(e -> checkFull());
        sizeBtn.addActionListener(e -> showSize());
    }

    private void setQueueSize() {
        try {
            capacity = Integer.parseInt(sizeField.getText().trim());
            if (capacity <= 0) throw new Exception();

            queue = new String[capacity];
            front = rear = -1;

            queuePanel.removeAll();
            queuePanel.setLayout(new GridLayout(1, capacity, 10, 10));

            for (int i = 0; i < capacity; i++) {
                JLabel cell = new JLabel("", SwingConstants.CENTER);
                cell.setOpaque(true);
                cell.setBackground(Color.WHITE);
                cell.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                cell.setFont(new Font("Arial", Font.BOLD, 16));
                queuePanel.add(cell);
            }

            queuePanel.revalidate();
            queuePanel.repaint();

            enableButtons();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Enter valid queue size!");
        }
    }

    private void enqueue() {
        if (rear == capacity - 1) {
            JOptionPane.showMessageDialog(this, "Queue Overflow!");
            return;
        }

        String value = valueField.getText().trim();
        if (value.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter a value!");
            return;
        }

        if (front == -1) front = 0;
        rear++;
        queue[rear] = value;

        updateQueueView();
        valueField.setText("");
    }

    private void dequeue() {
        if (front == -1) {
            JOptionPane.showMessageDialog(this, "Queue Underflow!");
            return;
        }

        String removed = queue[front];
        JOptionPane.showMessageDialog(this, "Dequeued: " + removed);

        queue[front] = null;

        if (front == rear) {
            front = rear = -1;
        } else {
            front++;
        }

        updateQueueView();
    }

    private void peek() {
        if (front == -1) {
            JOptionPane.showMessageDialog(this, "Queue is empty!");
            return;
        }
        JOptionPane.showMessageDialog(this, "Front: " + queue[front]);
    }

    private void checkEmpty() {
        JOptionPane.showMessageDialog(this, front == -1 ? "Queue is EMPTY" : "Queue is NOT empty");
    }

    private void checkFull() {
        JOptionPane.showMessageDialog(this, rear == capacity - 1 ? "Queue is FULL" : "Queue is NOT full");
    }

    private void showSize() {
        JOptionPane.showMessageDialog(this, "Current Size: " + (front == -1 ? 0 : rear - front + 1));
    }

    private void updateQueueView() {
        Component[] cells = queuePanel.getComponents();
        for (int i = 0; i < capacity; i++) {
            JLabel label = (JLabel) cells[i];
            label.setText(queue[i] == null ? "" : queue[i]);
        }
    }

    private void disableButtons() {
        enqueueBtn.setEnabled(false);
        dequeueBtn.setEnabled(false);
        peekBtn.setEnabled(false);
        isEmptyBtn.setEnabled(false);
        isFullBtn.setEnabled(false);
        sizeBtn.setEnabled(false);
    }

    private void enableButtons() {
        enqueueBtn.setEnabled(true);
        dequeueBtn.setEnabled(true);
        peekBtn.setEnabled(true);
        isEmptyBtn.setEnabled(true);
        isFullBtn.setEnabled(true);
        sizeBtn.setEnabled(true);
    }


}
